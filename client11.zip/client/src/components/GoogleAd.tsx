import { useEffect, useRef } from 'react';

interface GoogleAdProps {
  slot: string;
  format?: string;
  responsive?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

/**
 * GoogleAd Component - Renders Google AdSense ads
 * 
 * @param props.slot - AdSense ad slot ID (required)
 * @param props.format - Ad format (default: 'auto')
 * @param props.responsive - Whether ad should be responsive (default: true)
 * @param props.style - Custom inline styles
 * @param props.className - Custom CSS classes
 */
const GoogleAd: React.FC<GoogleAdProps> = ({ 
  slot, 
  format = 'auto', 
  responsive = true, 
  style = {}, 
  className = '' 
}) => {
  const adRef = useRef<HTMLModElement>(null);

  useEffect(() => {
    try {
      // Check if adsbygoogle is available and push the ad
      if (typeof window !== 'undefined' && (window as any).adsbygoogle) {
        ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
      }
    } catch (error) {
      console.warn('Google AdSense error:', error);
    }
  }, []);

  // Don't render if slot is not provided
  if (!slot) {
    console.warn('GoogleAd: slot prop is required');
    return null;
  }

  return (
    <div className={`google-ad-container ${className}`} style={{ textAlign: 'center', margin: '20px 0' }}>
      <ins
        ref={adRef}
        className="adsbygoogle"
        style={{
          display: 'block',
          ...style
        }}
        data-ad-client="ca-pub-7546322979632632"
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive.toString()}
        data-testid="google-ad"
      />
    </div>
  );
};

export default GoogleAd;