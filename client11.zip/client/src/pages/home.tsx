import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  KeyRound, 
  User, 
  Search, 
  Mail,
  Sparkles
} from "lucide-react";

interface ToolCard {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  href: string;
  gradient: string;
}

const tools: ToolCard[] = [
  {
    id: "password-generator",
    title: "Password Generator",
    description: "Create secure passwords with customizable length and character options",
    icon: <KeyRound className="w-8 h-8" />,
    href: "/password-generator",
    gradient: "from-primary to-secondary"
  },
  {
    id: "nickname-generator", 
    title: "Nickname Generator",
    description: "Generate creative nicknames for gaming, social media, and more",
    icon: <User className="w-8 h-8" />,
    href: "/nickname-generator",
    gradient: "from-secondary to-primary"
  },
  {
    id: "username-checker",
    title: "Username Availability",
    description: "Check username availability across Instagram, TikTok, X, and YouTube",
    icon: <Search className="w-8 h-8" />,
    href: "/username-checker",
    gradient: "from-primary via-secondary to-primary"
  },
  {
    id: "email-generator",
    title: "Random Email Generator", 
    description: "Generate random email addresses with popular domain options",
    icon: <Mail className="w-8 h-8" />,
    href: "/email-generator",
    gradient: "from-secondary to-primary"
  }
];

export default function Home() {
  const [, navigate] = useLocation();

  const handleCardClick = (href: string) => {
    navigate(href);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden py-16 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 dark:from-primary/10 dark:to-secondary/10" />
        
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="fade-in-slide">
            <div className="flex items-center justify-center mb-6">
              <Sparkles className="w-12 h-12 text-primary mr-3" />
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Identity Tools Hub
              </h1>
            </div>
            
            <p className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12">
              Your complete toolkit for digital identity management. Generate secure passwords, 
              create unique usernames, and build your online presence with style.
            </p>
          </div>
        </div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-8">
          {tools.map((tool, index) => (
            <Card
              key={tool.id}
              className={`
                floating-card card-glow ripple cursor-pointer 
                border-2 border-border hover:border-primary/50 
                transition-all duration-300 group
                fade-in-slide
              `}
              style={{ animationDelay: `${(index + 1) * 100}ms` }}
              onClick={() => handleCardClick(tool.href)}
              data-testid={`card-tool-${tool.id}`}
            >
              <CardHeader className="text-center pb-4">
                <div className={`
                  mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br ${tool.gradient} 
                  flex items-center justify-center text-white mb-4
                  group-hover:scale-110 transition-transform duration-300
                  shadow-lg group-hover:shadow-xl
                `}>
                  {tool.icon}
                </div>
                
                <CardTitle className="text-2xl font-bold text-foreground group-hover:text-primary transition-colors">
                  {tool.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="text-center">
                <CardDescription className="text-lg leading-relaxed">
                  {tool.description}
                </CardDescription>
                
                <div className="mt-6 inline-flex items-center px-4 py-2 rounded-full bg-muted text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                  <span className="font-medium">Get Started</span>
                  <svg 
                    className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bg-muted/30 border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Built for Modern Digital Identity
          </h3>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Streamline your online presence with professional-grade tools designed for 
            security, creativity, and efficiency. Perfect for content creators, gamers, and digital professionals.
          </p>
        </div>
      </div>
    </div>
  );
}