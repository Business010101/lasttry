import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, XCircle, Search, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PlatformResult {
  platform: string;
  status: "available" | "taken" | "unknown";
  error?: string;
}

interface UsernameCheckResponse {
  username: string;
  results: PlatformResult[];
}

const PLATFORMS = [
  { id: "instagram", name: "Instagram", icon: "IG" },
  { id: "tiktok", name: "TikTok", icon: "TT" },
  { id: "x", name: "X (Twitter)", icon: "X" },
  { id: "youtube", name: "YouTube", icon: "YT" }
];

export default function UsernameChecker() {
  const [username, setUsername] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["instagram", "tiktok", "x", "youtube"]);
  const { toast } = useToast();

  const mutation = useMutation<UsernameCheckResponse, Error, { username: string; platforms: string[] }>({
    mutationFn: async ({ username, platforms }) => {
      try {
        const response = await apiRequest("POST", "/api/check-username", { username, platforms });
        return await response.json();
      } catch (error: any) {
        // Handle specific error cases from the server
        if (error.message?.includes("429")) {
          throw new Error("Rate limit exceeded. Please wait a moment and try again.");
        } else if (error.message?.includes("400")) {
          throw new Error("Invalid username or platform selection.");
        } else {
          throw new Error("Failed to check username availability. Please try again.");
        }
      }
    },
    onError: (error) => {
      toast({
        title: "Error checking username",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleCheck = () => {
    if (!username.trim()) {
      toast({
        title: "Username Required",
        description: "Please enter a username to check.",
        variant: "destructive",
      });
      return;
    }

    if (selectedPlatforms.length === 0) {
      toast({
        title: "Select Platforms",
        description: "Please select at least one platform to check.",
        variant: "destructive",
      });
      return;
    }

    mutation.mutate({ username: username.trim(), platforms: selectedPlatforms });
  };

  const handlePlatformChange = (platformId: string, checked: boolean) => {
    if (checked) {
      setSelectedPlatforms(prev => [...prev, platformId]);
    } else {
      setSelectedPlatforms(prev => prev.filter(p => p !== platformId));
    }
    mutation.reset(); // Reset mutation state when platforms change
  };

  const handleUsernameChange = (value: string) => {
    setUsername(value);
    mutation.reset(); // Reset mutation state when username changes
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "available":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "taken":
        return <XCircle className="h-4 w-4 text-red-500" />;
      case "unknown":
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "available":
        return <Badge variant="secondary" className="bg-green-500/20 text-green-500 border-green-500/30">Available</Badge>;
      case "taken":
        return <Badge variant="destructive" className="bg-red-500/20 text-red-500 border-red-500/30">Taken</Badge>;
      case "unknown":
        return <Badge variant="outline" className="bg-yellow-500/20 text-yellow-500 border-yellow-500/30">Unknown</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 p-4">
      <div className="max-w-4xl mx-auto pt-8">
        <Card className="floating-card border-border/50 bg-card/95 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary via-purple-500 to-blue-500 bg-clip-text text-transparent">
              Username Availability Checker
            </CardTitle>
            <CardDescription className="text-lg text-muted-foreground">
              Check if your desired username is available across popular social platforms
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium">
                Username
              </Label>
              <Input
                id="username"
                data-testid="input-username"
                placeholder="Enter username to check..."
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                className="bg-background/50 border-border/70 focus:border-primary/50"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">Platforms to Check</Label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {PLATFORMS.map((platform) => (
                  <div key={platform.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={platform.id}
                      data-testid={`checkbox-${platform.id}`}
                      checked={selectedPlatforms.includes(platform.id)}
                      onCheckedChange={(checked) => handlePlatformChange(platform.id, checked as boolean)}
                    />
                    <Label htmlFor={platform.id} className="text-sm font-medium cursor-pointer">
                      <div className="flex items-center gap-2">
                        <span className="bg-primary/20 text-primary px-1.5 py-0.5 rounded text-xs font-bold">
                          {platform.icon}
                        </span>
                        {platform.name}
                      </div>
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <Button
              onClick={handleCheck}
              disabled={mutation.isPending || !username.trim() || selectedPlatforms.length === 0}
              className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white font-medium py-2.5"
              data-testid="button-check"
            >
              {mutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Checking Availability...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Check Availability
                </>
              )}
            </Button>

            {mutation.error && (
              <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500" data-testid="error-message">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  <span className="font-medium">Error checking username</span>
                </div>
                <p className="text-sm mt-1">
                  {mutation.error.message || "Failed to check username availability. Please try again."}
                </p>
              </div>
            )}

            {mutation.data && mutation.data.results && (
              <div className="space-y-4" data-testid="results-container">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Search className="h-4 w-4" />
                  <span>Results for "{mutation.data.username}"</span>
                </div>
                
                <div className="grid gap-3">
                  {mutation.data.results.map((result) => {
                    const platform = PLATFORMS.find(p => p.id === result.platform);
                    return (
                      <Card key={result.platform} className="p-4 bg-background/30 border-border/50" data-testid={`result-${result.platform}`}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="bg-primary/20 text-primary px-2 py-1 rounded text-sm font-bold">
                              {platform?.icon || result.platform.toUpperCase().slice(0, 2)}
                            </span>
                            <div>
                              <p className="font-medium">{platform?.name || result.platform}</p>
                              {result.error && (
                                <p className="text-xs text-muted-foreground">{result.error}</p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(result.status)}
                            {getStatusBadge(result.status)}
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>

                <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded-lg">
                  <p><strong>Note:</strong> Results are checked in real-time but social platforms change frequently. 
                  "Unknown" status means we couldn't determine availability - the username might still be available. 
                  Always verify directly on the platform before making final decisions.</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}