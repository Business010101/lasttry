import { useState, useEffect, useCallback } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Copy, Mail, RefreshCw, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const EMAIL_DOMAINS = [
  "gmail.com", "yahoo.com", "outlook.com", "hotmail.com", 
  "icloud.com", "protonmail.com", "aol.com", "mail.com",
  "zoho.com", "tutanota.com", "fastmail.com", "yandex.com"
];

const EMAIL_PATTERNS = [
  { id: "firstname_lastname", name: "Firstname Lastname", example: "john.doe" },
  { id: "username", name: "Username Style", example: "cooluser123" },
  { id: "word_combination", name: "Word Combination", example: "happy.dolphin" },
  { id: "random_letters", name: "Random Letters", example: "xj7k2m9p" },
  { id: "name_numbers", name: "Name + Numbers", example: "alex2024" }
];

const FIRST_NAMES = [
  "alex", "sam", "jordan", "casey", "taylor", "morgan", "riley", "jamie", 
  "avery", "blake", "cameron", "drew", "emery", "finley", "gray", "hunter"
];

const LAST_NAMES = [
  "smith", "johnson", "williams", "brown", "jones", "garcia", "miller", "davis",
  "rodriguez", "martinez", "hernandez", "lopez", "gonzalez", "wilson", "anderson", "thomas"
];

const WORDS = [
  "happy", "blue", "swift", "bright", "cool", "smart", "quick", "brave",
  "calm", "bold", "wise", "kind", "pure", "wild", "free", "gentle",
  "ocean", "star", "moon", "sun", "fire", "wind", "rain", "snow",
  "mountain", "river", "forest", "field", "cloud", "storm", "light", "shadow"
];

export default function EmailGenerator() {
  const [domain, setDomain] = useState("gmail.com");
  const [pattern, setPattern] = useState("firstname_lastname");
  const [count, setCount] = useState([3]);
  const [generatedEmails, setGeneratedEmails] = useState<string[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const { toast } = useToast();

  const generateRandomString = (length: number): string => {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const generateEmail = (): string => {
    let localPart = '';
    
    switch (pattern) {
      case 'firstname_lastname':
        const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
        const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
        localPart = `${firstName}.${lastName}`;
        break;
        
      case 'username':
        const username = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
        const randomNum = Math.floor(Math.random() * 999) + 1;
        localPart = `${username}${randomNum}`;
        break;
        
      case 'word_combination':
        const word1 = WORDS[Math.floor(Math.random() * WORDS.length)];
        const word2 = WORDS[Math.floor(Math.random() * WORDS.length)];
        localPart = `${word1}.${word2}`;
        break;
        
      case 'random_letters':
        localPart = generateRandomString(8);
        break;
        
      case 'name_numbers':
        const name = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
        const currentYear = new Date().getFullYear();
        const year = Math.floor(Math.random() * (currentYear - 2000 + 1)) + 2000; // 2000-2025
        localPart = `${name}${year}`;
        break;
        
      default:
        localPart = generateRandomString(8);
    }
    
    return `${localPart}@${domain}`;
  };

  const handleGenerate = useCallback(() => {
    const emails: string[] = [];
    const emailCount = count[0];
    
    for (let i = 0; i < emailCount; i++) {
      emails.push(generateEmail());
    }
    
    setGeneratedEmails(emails);
    setCopiedIndex(null);
    
    toast({
      title: "Emails Generated!",
      description: `Generated ${emailCount} random email${emailCount > 1 ? 's' : ''}.`,
    });
  }, [domain, pattern, count, toast]);

  const copyToClipboard = async (email: string, index: number) => {
    try {
      await navigator.clipboard.writeText(email);
      setCopiedIndex(index);
      
      toast({
        title: "Copied!",
        description: "Email copied to clipboard.",
      });
      
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy email to clipboard.",
        variant: "destructive",
      });
    }
  };

  // Auto-generate emails on mount and when settings change
  useEffect(() => {
    handleGenerate();
  }, [handleGenerate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 p-4">
      <div className="max-w-4xl mx-auto pt-8">
        <Card className="floating-card border-border/50 bg-card/95 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary via-purple-500 to-blue-500 bg-clip-text text-transparent">
              Random Email Generator
            </CardTitle>
            <CardDescription className="text-lg text-muted-foreground">
              Generate random email addresses for testing, privacy, or temporary use
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="domain" className="text-sm font-medium">
                  Email Domain
                </Label>
                <Select value={domain} onValueChange={setDomain}>
                  <SelectTrigger className="bg-background/50 border-border/70 focus:border-primary/50" data-testid="select-domain">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {EMAIL_DOMAINS.map((d) => (
                      <SelectItem key={d} value={d}>
                        @{d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pattern" className="text-sm font-medium">
                  Email Pattern
                </Label>
                <Select value={pattern} onValueChange={setPattern}>
                  <SelectTrigger className="bg-background/50 border-border/70 focus:border-primary/50" data-testid="select-pattern">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {EMAIL_PATTERNS.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        <div className="flex flex-col">
                          <span>{p.name}</span>
                          <span className="text-xs text-muted-foreground">{p.example}@domain.com</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">
                Number of Emails: {count[0]}
              </Label>
              <Slider
                value={count}
                onValueChange={setCount}
                max={10}
                min={1}
                step={1}
                className="w-full"
                data-testid="slider-count"
              />
            </div>

            <Button
              onClick={handleGenerate}
              className="w-full bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90 text-white font-medium py-2.5"
              data-testid="button-generate"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Generate Random Emails
            </Button>

            {generatedEmails.length > 0 && (
              <div className="space-y-4" data-testid="results-container">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  <span>Generated Emails</span>
                  <Badge variant="secondary" className="ml-auto">
                    {generatedEmails.length} email{generatedEmails.length > 1 ? 's' : ''}
                  </Badge>
                </div>
                
                <div className="grid gap-3">
                  {generatedEmails.map((email, index) => (
                    <Card key={index} className="p-4 bg-background/30 border-border/50" data-testid={`email-${index}`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="font-mono text-sm truncate">{email}</span>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(email, index)}
                          className="ml-3 flex-shrink-0"
                          data-testid={`button-copy-${index}`}
                        >
                          {copiedIndex === index ? (
                            <Check className="h-4 w-4 text-green-500" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>

                <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded-lg">
                  <p><strong>Note:</strong> These are randomly generated email addresses for testing purposes only. 
                  They may not be real or active email accounts. Use responsibly and respect privacy policies when using generated emails.</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}