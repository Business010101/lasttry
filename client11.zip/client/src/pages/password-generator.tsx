import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { KeyRound, Copy, ArrowLeft, RefreshCw, CheckCircle } from "lucide-react";

export default function PasswordGenerator() {
  const [length, setLength] = useState([12]);
  const [includeUppercase, setIncludeUppercase] = useState(true);
  const [includeLowercase, setIncludeLowercase] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [password, setPassword] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [justCopied, setJustCopied] = useState(false);
  
  const { toast } = useToast();

  const generatePassword = () => {
    setIsGenerating(true);
    
    // Define character sets
    const charSets = {
      uppercase: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
      lowercase: "abcdefghijklmnopqrstuvwxyz", 
      numbers: "0123456789",
      symbols: "!@#$%^&*()_+-=[]{}|;:,.<>?"
    };
    
    // Collect enabled character sets
    const enabledSets = [];
    if (includeUppercase) enabledSets.push(charSets.uppercase);
    if (includeLowercase) enabledSets.push(charSets.lowercase);
    if (includeNumbers) enabledSets.push(charSets.numbers);
    if (includeSymbols) enabledSets.push(charSets.symbols);
    
    if (enabledSets.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one character type",
        variant: "destructive",
      });
      setIsGenerating(false);
      return;
    }
    
    // Create full charset for remaining characters
    const fullCharset = enabledSets.join("");
    
    try {
      let result = "";
      const targetLength = length[0];
      
      // Ensure at least one character from each enabled set
      for (const charset of enabledSets) {
        if (result.length < targetLength) {
          result += getSecureRandomChar(charset);
        }
      }
      
      // Fill remaining length with random characters from full charset
      while (result.length < targetLength) {
        result += getSecureRandomChar(fullCharset);
      }
      
      // Shuffle the result to avoid predictable patterns
      result = shuffleString(result);
      
      setPassword(result);
      setIsGenerating(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate secure password. Please try again.",
        variant: "destructive",
      });
      setIsGenerating(false);
    }
  };

  // Cryptographically secure random character selection
  const getSecureRandomChar = (charset: string): string => {
    const array = new Uint32Array(1);
    let randomIndex;
    
    // Use rejection sampling to avoid modulo bias
    do {
      window.crypto.getRandomValues(array);
      randomIndex = array[0];
    } while (randomIndex >= Math.floor(0x100000000 / charset.length) * charset.length);
    
    return charset[randomIndex % charset.length];
  };

  // Cryptographically secure string shuffling
  const shuffleString = (str: string): string => {
    const arr = str.split("");
    for (let i = arr.length - 1; i > 0; i--) {
      const array = new Uint32Array(1);
      window.crypto.getRandomValues(array);
      const j = array[0] % (i + 1);
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.join("");
  };

  const copyToClipboard = async () => {
    if (!password) return;
    
    try {
      await navigator.clipboard.writeText(password);
      setJustCopied(true);
      
      toast({
        title: "Copied!",
        description: "Password copied to clipboard",
        className: "toast-success",
      });
      
      setTimeout(() => setJustCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy password",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Tools
              </Button>
            </Link>
            
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <KeyRound className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Password Generator</h1>
                <p className="text-sm text-muted-foreground">Create secure passwords with customizable options</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Settings Panel */}
          <div className="lg:col-span-1">
            <Card className="floating-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <RefreshCw className="w-5 h-5" />
                  Settings
                </CardTitle>
                <CardDescription>
                  Customize your password generation options
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Length Slider */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="length">Password Length</Label>
                    <span className="text-sm font-mono bg-muted px-2 py-1 rounded">
                      {length[0]}
                    </span>
                  </div>
                  <Slider
                    id="length"
                    min={6}
                    max={64}
                    step={1}
                    value={length}
                    onValueChange={setLength}
                    className="w-full"
                    data-testid="slider-length"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>6</span>
                    <span>64</span>
                  </div>
                </div>

                {/* Character Type Options */}
                <div className="space-y-4">
                  <Label>Include Characters</Label>
                  
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="uppercase"
                        checked={includeUppercase}
                        onCheckedChange={(checked) => setIncludeUppercase(checked === true)}
                        data-testid="checkbox-uppercase"
                      />
                      <Label htmlFor="uppercase" className="text-sm">
                        Uppercase Letters (A-Z)
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="lowercase"
                        checked={includeLowercase}
                        onCheckedChange={(checked) => setIncludeLowercase(checked === true)}
                        data-testid="checkbox-lowercase"
                      />
                      <Label htmlFor="lowercase" className="text-sm">
                        Lowercase Letters (a-z)
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="numbers"
                        checked={includeNumbers}
                        onCheckedChange={(checked) => setIncludeNumbers(checked === true)}
                        data-testid="checkbox-numbers"
                      />
                      <Label htmlFor="numbers" className="text-sm">
                        Numbers (0-9)
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id="symbols"
                        checked={includeSymbols}
                        onCheckedChange={(checked) => setIncludeSymbols(checked === true)}
                        data-testid="checkbox-symbols"
                      />
                      <Label htmlFor="symbols" className="text-sm">
                        Symbols (!@#$%^&*)
                      </Label>
                    </div>
                  </div>
                </div>

                {/* Generate Button */}
                <Button
                  onClick={generatePassword}
                  disabled={isGenerating}
                  className="w-full gaming-gradient ripple"
                  size="lg"
                  data-testid="button-generate"
                >
                  {isGenerating ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <KeyRound className="w-4 h-4 mr-2" />
                  )}
                  Generate Password
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Result Panel */}
          <div className="lg:col-span-2">
            <Card className="floating-card">
              <CardHeader>
                <CardTitle>Generated Password</CardTitle>
                <CardDescription>
                  {password ? "Your secure password is ready" : "Click generate to create a password"}
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Password Display */}
                <div className="relative">
                  <Input
                    value={password}
                    readOnly
                    placeholder="Your generated password will appear here..."
                    className="font-mono text-lg pr-12 bg-muted/50"
                    data-testid="input-password"
                  />
                  {password && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={copyToClipboard}
                      className={`absolute right-1 top-1 h-8 w-8 p-0 ${
                        justCopied ? "text-green-600" : "text-muted-foreground hover:text-foreground"
                      }`}
                      data-testid="button-copy"
                    >
                      {justCopied ? (
                        <CheckCircle className="w-4 h-4" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  )}
                </div>

                {/* Password Strength Indicator */}
                {password && (
                  <div className="space-y-2">
                    <Label className="text-sm">Password Strength</Label>
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <div
                          key={i}
                          className={`h-2 flex-1 rounded-full ${
                            i < Math.min(5, Math.floor(password.length / 8) + 1)
                              ? i < 2
                                ? "bg-red-500"
                                : i < 4
                                ? "bg-yellow-500"
                                : "bg-green-500"
                              : "bg-muted"
                          }`}
                        />
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {password.length < 8
                        ? "Weak - Consider using more characters"
                        : password.length < 12
                        ? "Good - Nice balance of security and usability"
                        : "Strong - Excellent security"}
                    </p>
                  </div>
                )}

                {/* Tips */}
                <div className="mt-6 p-4 bg-muted/30 rounded-lg border">
                  <h4 className="font-medium text-sm mb-2">💡 Password Tips</h4>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Use at least 12 characters for better security</li>
                    <li>• Include a mix of uppercase, lowercase, numbers, and symbols</li>
                    <li>• Don't reuse passwords across multiple accounts</li>
                    <li>• Consider using a password manager</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}