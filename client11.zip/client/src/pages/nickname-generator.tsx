import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { User, Copy, ArrowLeft, Sparkles, CheckCircle } from "lucide-react";

type NicknameStyle = "gamer" | "cute" | "aesthetic" | "random";

interface GeneratedNickname {
  id: string;
  name: string;
  justCopied: boolean;
}

export default function NicknameGenerator() {
  const [style, setStyle] = useState<NicknameStyle>("gamer");
  const [count, setCount] = useState([3]);
  const [nicknames, setNicknames] = useState<GeneratedNickname[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const { toast } = useToast();

  // Nickname generation data
  const nicknameData = {
    gamer: {
      prefixes: ["Shadow", "Dark", "Silent", "Phantom", "Nova", "Cyber", "Neon", "Alpha", "Beta", "Zero", "Fire", "Ice", "Storm", "Thunder", "Lightning", "Blade", "Steel", "Iron", "Ghost", "Raven", "Wolf", "Dragon", "Phoenix", "Viper", "Hawk", "Eagle", "Tiger", "Lion", "Bear", "Frost", "Rage", "Blood", "Death", "Soul", "Spirit"],
      suffixes: ["Hunter", "Killer", "Warrior", "Master", "Lord", "King", "Queen", "Slayer", "Destroyer", "Reaper", "Knight", "Assassin", "Ninja", "Samurai", "Guardian", "Defender", "Striker", "Sniper", "Ranger", "Scout", "Phantom", "Legend", "Myth", "Hero", "Champion", "Gladiator", "Berserker", "Crusader", "Templar", "Paladin", "Rogue", "Mage", "Wizard", "Sorcerer", "Witch"]
    },
    cute: {
      prefixes: ["Sweet", "Fluffy", "Tiny", "Little", "Baby", "Honey", "Sugar", "Cookie", "Cupcake", "Muffin", "Bunny", "Kitty", "Puppy", "Panda", "Teddy", "Angel", "Star", "Moon", "Sun", "Flower", "Rose", "Lily", "Daisy", "Cherry", "Peach", "Berry", "Candy", "Bubble", "Sparkle", "Glitter", "Rainbow", "Cloud", "Dream", "Fairy", "Princess"],
      suffixes: ["Bean", "Pie", "Cake", "Pop", "Drop", "Dot", "Bun", "Puff", "Fluff", "Fuzz", "Whiskers", "Paws", "Tail", "Wings", "Heart", "Love", "Kiss", "Hug", "Smile", "Giggle", "Laugh", "Joy", "Happy", "Sunny", "Bright", "Shine", "Glow", "Twinkle", "Sparkle", "Magic", "Wonder", "Dream", "Hope", "Wish"]
    },
    aesthetic: {
      prefixes: ["Velvet", "Silk", "Pearl", "Crystal", "Diamond", "Gold", "Silver", "Platinum", "Marble", "Ivory", "Jade", "Ruby", "Sapphire", "Emerald", "Onyx", "Opal", "Quartz", "Amethyst", "Topaz", "Garnet", "Moonstone", "Sunstone", "Starlight", "Twilight", "Aurora", "Serenity", "Harmony", "Melody", "Symphony", "Rhapsody", "Sonata", "Aria", "Echo", "Whisper", "Ethereal"],
      suffixes: ["Mist", "Glow", "Shimmer", "Gleam", "Radiance", "Luminous", "Celestial", "Divine", "Sublime", "Elegant", "Grace", "Charm", "Allure", "Beauty", "Wonder", "Mystique", "Enigma", "Mirage", "Vision", "Dream", "Fantasy", "Reverie", "Serendipity", "Bliss", "Euphoria", "Nirvana", "Zenith", "Infinity", "Eternity", "Cosmos", "Galaxy", "Nebula", "Stardust", "Solace", "Tranquil"]
    }
  };

  const generateNicknames = () => {
    setIsGenerating(true);
    
    const results: GeneratedNickname[] = [];
    const targetCount = count[0];
    
    for (let i = 0; i < targetCount; i++) {
      let nickname = "";
      
      if (style === "random") {
        // Pick a random style for each nickname
        const styles: Array<Exclude<NicknameStyle, "random">> = ["gamer", "cute", "aesthetic"];
        const randomStyle = styles[Math.floor(Math.random() * styles.length)];
        nickname = generateSingleNickname(randomStyle);
      } else {
        nickname = generateSingleNickname(style);
      }
      
      results.push({
        id: `nickname-${i}-${Date.now()}`,
        name: nickname,
        justCopied: false
      });
    }
    
    // Add a small delay for better UX
    setTimeout(() => {
      setNicknames(results);
      setIsGenerating(false);
    }, 300);
  };

  const generateSingleNickname = (selectedStyle: Exclude<NicknameStyle, "random">): string => {
    const data = nicknameData[selectedStyle];
    const prefix = data.prefixes[Math.floor(Math.random() * data.prefixes.length)];
    const suffix = data.suffixes[Math.floor(Math.random() * data.suffixes.length)];
    
    // Sometimes add numbers for variety
    const addNumber = Math.random() < 0.3;
    const number = addNumber ? Math.floor(Math.random() * 999) + 1 : "";
    
    return `${prefix}${suffix}${number}`;
  };

  const copyNickname = async (nickname: GeneratedNickname) => {
    try {
      await navigator.clipboard.writeText(nickname.name);
      
      // Update the specific nickname's copy state
      setNicknames(prev => prev.map(n => 
        n.id === nickname.id 
          ? { ...n, justCopied: true }
          : { ...n, justCopied: false }
      ));
      
      toast({
        title: "Copied!",
        description: `"${nickname.name}" copied to clipboard`,
        className: "toast-success",
      });
      
      // Reset the copy state after 2 seconds
      setTimeout(() => {
        setNicknames(prev => prev.map(n => 
          n.id === nickname.id 
            ? { ...n, justCopied: false }
            : n
        ));
      }, 2000);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy nickname",
        variant: "destructive",
      });
    }
  };

  const getStyleDescription = (selectedStyle: NicknameStyle): string => {
    switch (selectedStyle) {
      case "gamer":
        return "Epic gaming names with power and intensity";
      case "cute":
        return "Sweet and adorable names perfect for social media";
      case "aesthetic":
        return "Elegant and artistic names with sophisticated vibes";
      case "random":
        return "Mix of all styles for maximum variety";
      default:
        return "";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Tools
              </Button>
            </Link>
            
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-secondary to-primary flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Nickname Generator</h1>
                <p className="text-sm text-muted-foreground">Create unique nicknames for gaming, social media, and more</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Settings Panel */}
          <div className="lg:col-span-1">
            <Card className="floating-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Generator Settings
                </CardTitle>
                <CardDescription>
                  Customize your nickname generation preferences
                </CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Style Selection */}
                <div className="space-y-3">
                  <Label htmlFor="style">Nickname Style</Label>
                  <Select value={style} onValueChange={(value: NicknameStyle) => setStyle(value)}>
                    <SelectTrigger data-testid="select-style">
                      <SelectValue placeholder="Choose a style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gamer">🎮 Gamer</SelectItem>
                      <SelectItem value="cute">🥰 Cute</SelectItem>
                      <SelectItem value="aesthetic">✨ Aesthetic</SelectItem>
                      <SelectItem value="random">🎲 Random</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    {getStyleDescription(style)}
                  </p>
                </div>

                {/* Count Slider */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="count">Number of Results</Label>
                    <span className="text-sm font-mono bg-muted px-2 py-1 rounded">
                      {count[0]}
                    </span>
                  </div>
                  <Slider
                    id="count"
                    min={1}
                    max={10}
                    step={1}
                    value={count}
                    onValueChange={setCount}
                    className="w-full"
                    data-testid="slider-count"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>1</span>
                    <span>10</span>
                  </div>
                </div>

                {/* Generate Button */}
                <Button
                  onClick={generateNicknames}
                  disabled={isGenerating}
                  className="w-full gaming-gradient ripple"
                  size="lg"
                  data-testid="button-generate"
                >
                  {isGenerating ? (
                    <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <User className="w-4 h-4 mr-2" />
                  )}
                  Generate Nicknames
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2">
            <Card className="floating-card">
              <CardHeader>
                <CardTitle>Generated Nicknames</CardTitle>
                <CardDescription>
                  {nicknames.length > 0 
                    ? `${nicknames.length} ${style} style nickname${nicknames.length > 1 ? 's' : ''} ready to use`
                    : "Click generate to create your nicknames"
                  }
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                {nicknames.length > 0 ? (
                  <div className="space-y-3">
                    {nicknames.map((nickname, index) => (
                      <div
                        key={nickname.id}
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border hover:bg-muted/50 transition-colors fade-in-slide"
                        style={{ animationDelay: `${index * 100}ms` }}
                        data-testid={`nickname-item-${index}`}
                      >
                        <span className="font-mono text-lg font-medium">
                          {nickname.name}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyNickname(nickname)}
                          className={`h-8 w-8 p-0 ${
                            nickname.justCopied 
                              ? "text-green-600" 
                              : "text-muted-foreground hover:text-foreground"
                          }`}
                          data-testid={`button-copy-${index}`}
                        >
                          {nickname.justCopied ? (
                            <CheckCircle className="w-4 h-4" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <User className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Your generated nicknames will appear here</p>
                    <p className="text-sm mt-2">Choose your style and hit generate!</p>
                  </div>
                )}

                {/* Tips */}
                {nicknames.length > 0 && (
                  <div className="mt-6 p-4 bg-muted/30 rounded-lg border">
                    <h4 className="font-medium text-sm mb-2">💡 Nickname Tips</h4>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>• Check availability on your favorite platforms</li>
                      <li>• Consider adding your birth year for uniqueness</li>
                      <li>• Mix and match elements from different results</li>
                      <li>• Keep it memorable and easy to type</li>
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}