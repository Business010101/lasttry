import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/hooks/use-theme";
import Navigation from "@/components/navigation";
import GoogleAd from "@/components/GoogleAd.tsx";
import Home from "@/pages/home";
import PasswordGenerator from "@/pages/password-generator";
import NicknameGenerator from "@/pages/nickname-generator";
import UsernameChecker from "@/pages/username-checker";
import EmailGenerator from "@/pages/email-generator";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/password-generator" component={PasswordGenerator} />
      <Route path="/nickname-generator" component={NicknameGenerator} />
      <Route path="/username-checker" component={UsernameChecker} />
      <Route path="/email-generator" component={EmailGenerator} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Navigation />
          <Toaster />
          <Router />
          {/* AdSense ad displayed on all pages */}
          <GoogleAd slot="1234567890" className="mt-8" />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
